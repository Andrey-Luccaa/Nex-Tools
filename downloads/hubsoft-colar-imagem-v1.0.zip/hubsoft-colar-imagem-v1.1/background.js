chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;

  try {
    await chrome.tabs.sendMessage(tab.id, { type: "HUBSOFT_TOGGLE_PANEL" });
  } catch (error) {
    console.error("Não foi possível abrir o painel:", error);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "HUBSOFT_CAPTURE_VISIBLE_TAB") return;

  const windowId = sender.tab?.windowId;

  chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (dataUrl) => {
    if (chrome.runtime.lastError) {
      sendResponse({
        ok: false,
        error: chrome.runtime.lastError.message
      });
      return;
    }

    sendResponse({ ok: true, dataUrl });
  });

  return true;
});
