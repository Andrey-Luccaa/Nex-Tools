(() => {
  if (
    location.hostname === "web.whatsapp.com" ||
    location.hostname.endsWith(".whatsapp.com")
  ) return;

  if (window.__hubsoftImagePasteLoaded) return;
  window.__hubsoftImagePasteLoaded = true;

  const state = {
    panel: null,
    toast: null,
    selectedInput: null
  };

  function isImageFile(file) {
    return file && file.type && file.type.startsWith("image/");
  }

  function getFileInputs() {
    return [...document.querySelectorAll('input[type="file"]')]
      .filter(input => !input.disabled);
  }

  function scoreInput(input) {
    let score = 0;
    const accept = (input.accept || "").toLowerCase();
    const text = [
      input.id,
      input.name,
      input.className,
      input.getAttribute("aria-label"),
      input.closest("label")?.innerText,
      input.parentElement?.innerText
    ].filter(Boolean).join(" ").toLowerCase();

    if (accept.includes("image")) score += 50;
    if (/anexo|arquivo|imagem|upload|attachment/.test(text)) score += 40;

    const rect = input.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) score += 10;

    return score;
  }

  function findBestInput() {
    if (state.selectedInput?.isConnected && !state.selectedInput.disabled) {
      return state.selectedInput;
    }

    const inputs = getFileInputs();
    if (!inputs.length) return null;

    return inputs
      .map(input => ({ input, score: scoreInput(input) }))
      .sort((a, b) => b.score - a.score)[0].input;
  }

  function createFileFromBlob(blob, prefix = "captura") {
    const extension = blob.type.split("/")[1]?.replace("jpeg", "jpg") || "png";
    return new File(
      [blob],
      `${prefix}-${new Date().toISOString().replace(/[:.]/g, "-")}.${extension}`,
      { type: blob.type || "image/png" }
    );
  }

  function mergeFiles(input, newFiles) {
    const transfer = new DataTransfer();

    [...(input.files || [])].forEach(file => transfer.items.add(file));
    newFiles.forEach(file => transfer.items.add(file));

    return transfer.files;
  }

  function attachFiles(files) {
    const images = [...files].filter(isImageFile);

    if (!images.length) {
      showToast("Nenhuma imagem encontrada.", "error");
      return false;
    }

    const input = findBestInput();

    if (!input) {
      showToast("Campo de anexo não encontrado nesta página.", "error");
      return false;
    }

    try {
      input.files = mergeFiles(input, images);

      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      const target = input.closest("label, .dropzone, [class*='upload'], [class*='anexo']") || input.parentElement;
      if (target) {
        const dataTransfer = new DataTransfer();
        images.forEach(file => dataTransfer.items.add(file));

        target.dispatchEvent(new DragEvent("drop", {
          bubbles: true,
          cancelable: true,
          dataTransfer
        }));
      }

      showToast(
        images.length === 1
          ? "Imagem anexada com sucesso."
          : `${images.length} imagens anexadas com sucesso.`,
        "success"
      );

      closePanel();
      return true;
    } catch (error) {
      console.error(error);
      showToast("O Hubsoft bloqueou o preenchimento automático do anexo.", "error");
      return false;
    }
  }

  async function pasteFromClipboard() {
    try {
      if (!navigator.clipboard?.read) {
        showToast("O navegador não liberou o acesso à área de transferência.", "error");
        return;
      }

      const items = await navigator.clipboard.read();
      const files = [];

      for (const item of items) {
        const imageType = item.types.find(type => type.startsWith("image/"));
        if (!imageType) continue;

        const blob = await item.getType(imageType);
        files.push(createFileFromBlob(blob, "imagem-colada"));
      }

      attachFiles(files);
    } catch (error) {
      console.error(error);
      showToast("Clique na página e tente novamente. O navegador pode ter bloqueado a leitura.", "error");
    }
  }

  async function captureVisibleTab() {
    try {
      showToast("Capturando a aba atual...", "info");

      const response = await chrome.runtime.sendMessage({
        type: "HUBSOFT_CAPTURE_VISIBLE_TAB"
      });

      if (!response?.ok) {
        throw new Error(response?.error || "Falha ao capturar a aba.");
      }

      const blob = await fetch(response.dataUrl).then(r => r.blob());
      attachFiles([createFileFromBlob(blob, "captura-aba")]);
    } catch (error) {
      console.error(error);
      showToast("Não foi possível capturar esta aba.", "error");
    }
  }

  async function captureScreen() {
    try {
      closePanel();

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { cursor: "always" },
        audio: false
      });

      const video = document.createElement("video");
      video.srcObject = stream;
      video.muted = true;
      await video.play();

      await new Promise(resolve => setTimeout(resolve, 300));

      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const context = canvas.getContext("2d");
      context.drawImage(video, 0, 0);

      stream.getTracks().forEach(track => track.stop());

      canvas.toBlob(blob => {
        if (!blob) {
          showToast("Não foi possível gerar a captura.", "error");
          return;
        }

        attachFiles([createFileFromBlob(blob, "captura-tela")]);
      }, "image/png");
    } catch (error) {
      if (error.name !== "NotAllowedError") {
        console.error(error);
        showToast("Não foi possível capturar a tela.", "error");
      }
    }
  }

  function chooseFile() {
    const input = findBestInput();

    if (input) {
      state.selectedInput = input;
      input.click();
      closePanel();
      return;
    }

    const temporaryInput = document.createElement("input");
    temporaryInput.type = "file";
    temporaryInput.accept = "image/*";
    temporaryInput.multiple = true;
    temporaryInput.style.display = "none";

    temporaryInput.addEventListener("change", () => {
      attachFiles(temporaryInput.files);
      temporaryInput.remove();
    }, { once: true });

    document.body.appendChild(temporaryInput);
    temporaryInput.click();
  }

  function showToast(message, type = "info") {
    state.toast?.remove();

    const toast = document.createElement("div");
    toast.className = `hubsoft-image-toast hubsoft-image-toast--${type}`;
    toast.textContent = message;
    document.documentElement.appendChild(toast);
    state.toast = toast;

    requestAnimationFrame(() => toast.classList.add("is-visible"));

    setTimeout(() => {
      toast.classList.remove("is-visible");
      setTimeout(() => toast.remove(), 250);
    }, 3200);
  }

  function closePanel() {
    if (!state.panel) return;
    state.panel.classList.remove("is-open");
  }

  function togglePanel() {
    ensureInterface();
    state.panel.classList.toggle("is-open");
  }

  function createButton(icon, title, subtitle, action) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "hubsoft-image-option";
    button.innerHTML = `
      <span class="hubsoft-image-option__icon">${icon}</span>
      <span class="hubsoft-image-option__text">
        <strong>${title}</strong>
        <small>${subtitle}</small>
      </span>
      <span class="hubsoft-image-option__arrow">›</span>
    `;
    button.addEventListener("click", action);
    return button;
  }

  function ensureInterface() {
    if (state.panel) return;

    const launcher = document.createElement("button");
    launcher.type = "button";
    launcher.className = "hubsoft-image-launcher";
    launcher.title = "Colar ou capturar imagem";
    launcher.setAttribute("aria-label", "Colar ou capturar imagem");
    launcher.innerHTML = `
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M8.5 6.5V5a3.5 3.5 0 0 1 7 0v9a5.5 5.5 0 0 1-11 0V6a2.5 2.5 0 0 1 5 0v8a1.5 1.5 0 0 1-3 0V7.5"
          fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      </svg>
    `;

    const panel = document.createElement("div");
    panel.className = "hubsoft-image-panel";
    panel.innerHTML = `
      <div class="hubsoft-image-panel__header">
        <div>
          <strong>Adicionar imagem</strong>
          <small>Sem precisar salvar no computador</small>
        </div>
        <button type="button" class="hubsoft-image-close" aria-label="Fechar">×</button>
      </div>
      <div class="hubsoft-image-panel__options"></div>
      <div class="hubsoft-image-panel__hint">
        Dica: use <kbd>Ctrl</kbd> + <kbd>V</kbd> com uma captura copiada.
      </div>
    `;

    const options = panel.querySelector(".hubsoft-image-panel__options");

    options.append(
      createButton("📋", "Colar imagem copiada", "Funciona com Win + Shift + S", pasteFromClipboard),
      createButton("🖥️", "Capturar aba atual", "Captura somente a página aberta", captureVisibleTab),
      createButton("📸", "Capturar tela ou janela", "Escolha uma tela, janela ou aba", captureScreen),
      createButton("📁", "Escolher arquivo", "Abrir o explorador do Windows", chooseFile)
    );

    launcher.addEventListener("click", togglePanel);
    panel.querySelector(".hubsoft-image-close").addEventListener("click", closePanel);

    document.addEventListener("click", event => {
      if (!panel.contains(event.target) && !launcher.contains(event.target)) {
        closePanel();
      }
    });

    document.documentElement.append(launcher, panel);

    state.panel = panel;
  }

  document.addEventListener("paste", event => {
    const files = [...(event.clipboardData?.files || [])].filter(isImageFile);
    if (!files.length) return;

    const input = findBestInput();
    if (!input) return;

    event.preventDefault();
    attachFiles(files);
  }, true);

  document.addEventListener("focusin", event => {
    if (event.target?.matches?.('input[type="file"]')) {
      state.selectedInput = event.target;
    }
  }, true);

  chrome.runtime.onMessage.addListener(message => {
    if (message?.type === "HUBSOFT_TOGGLE_PANEL") {
      togglePanel();
    }
  });

  ensureInterface();
})();
